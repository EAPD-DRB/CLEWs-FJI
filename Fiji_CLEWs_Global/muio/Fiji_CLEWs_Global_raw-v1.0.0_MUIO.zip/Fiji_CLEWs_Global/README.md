# Fiji CLEWs Global active MUIO case

This folder contains the portable raw MUIO case. The parameter JSON files
remain at this level because MUIO expects them here. Solver inputs and results
are generated after the case is opened and solved in MUIOGO.

The case is technically solved and deliberately uncalibrated. Its current
runs are `Raw` and `Raw_ReserveProxy`. It must not be used as a Fiji forecast
or as the basis for ranking renewable pathways.

- Current case navigation: `documentation/README.md`
- Sources, assumptions, calculations, model map, current documentation,
  history, and diagnostics:
  https://github.com/EAPD-DRB/CLEWs-FJI/tree/main/Fiji_CLEWs_Global

Historical files in the build package may contain old filenames because they
record the state at that date. They are evidence, not current navigation
instructions.

The addition of these README files did not change any parameter JSON, scenario
definition, result, or solver input in the active case.
