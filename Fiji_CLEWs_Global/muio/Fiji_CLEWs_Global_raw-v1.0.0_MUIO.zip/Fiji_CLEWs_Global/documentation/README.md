# Fiji active-case documentation

The canonical documentation lives in the Fiji build package:

- Current model:
  `../../../../Fiji_CLEWs_Global/documentation/CURRENT_MODEL.md`
- Model structure:
  `../../../../Fiji_CLEWs_Global/documentation/MODEL_STRUCTURE.md`
- Known limitations:
  `../../../../Fiji_CLEWs_Global/documentation/KNOWN_LIMITATIONS.md`
- Calibration protocol:
  `../../../../Fiji_CLEWs_Global/documentation/CALIBRATION_PROTOCOL.md`
- History:
  `../../../../Fiji_CLEWs_Global/documentation/HISTORY.md`
- Sources, assumptions, calculations, and model map:
  `../../../../Fiji_CLEWs_Global/data_sources/`

This runtime folder contains no separate calibration ledger. Model changes
must first be documented in the canonical build package and then imported as a
separately versioned MUIO case. Do not edit the raw runtime JSON in place for
calibration.
