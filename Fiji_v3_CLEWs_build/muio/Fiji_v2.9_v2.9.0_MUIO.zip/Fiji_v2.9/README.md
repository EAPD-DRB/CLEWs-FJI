# Fiji v2.9

Fiji v2.9 extends the solved Fiji v2.8 CLEWs case with a population-driven
Fisheries food balance and explicit retained-import and domestic-export demand.

Two aggregate mass commodities are added: `FSHRAW` for domestic landed fish
and `FSHFOOD` for fish available to residents or domestic exports. Capture and
aquaculture useful services produce `FSHRAW`; post-harvest useful service turns
it into `FSHFOOD`. `IMPFSHFOOD` is an open, high-cost accounting backstop that
can meet additional demand if domestic production falls.

Annual `FSHFOOD` final demand is resident food availability plus 2025 domestic
exports, both scaled with the UN WPP 2024 medium population pathway. The
minimum import activity is the population-scaled 2025 retained-import proxy,
calculated from imports net of reported re-exports by HS heading. Tourism is
excluded.

Two non-forcing annual production ceilings prevent either domestic subsector
from expanding without limit: capture is capped at 23,661 tonnes/year, and
aquaculture follows an observed/programme envelope from 216.925 tonnes/year
through 2023 to 1,450 tonnes/year from 2028. Neither subsector has a production
floor; imports remain open if domestic supply is insufficient.

Permanent values reside in `genData.json` and the source `R*.json` files.
`population_fisheries_trade_v29_manifest.json` records the evidence snapshot,
annual series, assumptions and equation map. The validated bounded live run is
`res/Fisheries_Bounds_Table18_v2.9`; the former unconstrained run is preserved at
`res/Population_Fisheries_Trade_v2.9` as a baseline. See `MODEL_FIXES.md` and
`validation_fisheries_bounds_v29_final.json` for the complete solver chain,
baseline comparison and limitations.

The canonical six-ledger provenance package is
`docs/Fiji_v2.9_Population_Crop_Fisheries_Trade/`. It documents sources,
calculations, assumptions, source-to-model mappings, gaps and changes for the
v2.8 crop and v2.9 Fisheries demand/trade layers.

Important limitation: the capture ceiling is an observed-boundary proxy rather
than a legal quota or biological stock model. The aquaculture ceiling aggregates
feed, land, water, farm-expansion and environmental restrictions into a single
programme envelope. The resulting mix is a defensible screening representation,
not a species-level or facility-level forecast.
