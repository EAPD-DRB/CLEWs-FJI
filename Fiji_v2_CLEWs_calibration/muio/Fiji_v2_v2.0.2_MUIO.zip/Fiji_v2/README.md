# Fiji v2 active MUIO case

This folder is the active Fiji v2 runtime case. Its current solved run,
`Phase1B_Public_Water`, retains the annual national grid-supply calibration
experiment and adds the Phase 1B public-water closure. Energy calibration
uses 2020–2022 with frozen 2023–2024 held-out validation.

- Canonical package: `../../../Fiji_v2_CLEWs_calibration/`
- Current model:
  `../../../Fiji_v2_CLEWs_calibration/documentation/CURRENT_MODEL.md`
- Sources and evidence:
  `../../../Fiji_v2_CLEWs_calibration/data_sources/`
- Assessment:
  `../../../Fiji_v2_CLEWs_calibration/diagnostics/calibration_runs/historical_fit/scorecard.md`
- Validation:
  `../../../Fiji_v2_CLEWs_calibration/diagnostics/calibration_runs/phase1b/live_validation_summary.json`
- Phase 1B record:
  `../../../Fiji_v2_CLEWs_calibration/documentation/history/structural/PHASE_1B_PUBLIC_WATER_2026-07-27.md`

The case is **Good, 76.4/100, medium confidence** for annual energy only.
Its 2020–2024 public-water demand and surface abstraction ratios are
evidence-backed, but the full water and land-agriculture nexus remains
uncalibrated. It is not a forecast, reliability model, or decision-grade
investment plan.

Do not edit runtime JSON by hand. Rebuild from the immutable
`Fiji_CLEWs_Global` reference with `scripts/build_fiji_v2.py`, apply Phase 1B
with `scripts/apply_fiji_phase1b_public_water.py`, update the derived reserve
proxy, and rerun the automated solve and validation.
