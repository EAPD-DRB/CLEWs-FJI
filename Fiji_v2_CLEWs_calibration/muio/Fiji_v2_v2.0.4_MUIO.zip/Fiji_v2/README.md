# Fiji v2 active MUIO case

This folder is the active Fiji v2 runtime case. Its current solved run,
`Phase1C_BottomUp`, retains the annual national grid-supply calibration and
Phase 1B public-water closure, then decomposes grid electricity into
commercial, industrial, central-grid residential and direct-overhead demand.
Energy calibration uses 2020–2022 with frozen 2023–2024 held-out validation.

- Canonical package: `../../../Fiji_v2_CLEWs_calibration/`
- Current model:
  `../../../Fiji_v2_CLEWs_calibration/documentation/CURRENT_MODEL.md`
- Sources and evidence:
  `../../../Fiji_v2_CLEWs_calibration/data_sources/`
- Assessment:
  `../../../Fiji_v2_CLEWs_calibration/diagnostics/calibration_runs/historical_fit/scorecard.md`
- Validation:
  `../../../Fiji_v2_CLEWs_calibration/diagnostics/calibration_runs/phase1c/live_validation_summary.json`
- Phase 1C record:
  `../../../Fiji_v2_CLEWs_calibration/documentation/history/structural/PHASE_1C_BOTTOM_UP_ELECTRICITY_DEMAND_2026-07-27.md`
- Source locators and calculations:
  `../../../Fiji_v2_CLEWs_calibration/data_sources/evidence/energy/PHASE_1C_PROJECTION_SOURCE_EXTRACTS_2026-07-27.md`

The case is **Good, 76.4/100, medium confidence** for annual energy only.
Its 2020–2024 public-water demand, surface abstraction ratios and sector
electricity accounting are evidence-backed. Its 2025–2050 electricity demand
is a documented bottom-up base scenario, not a forecast. The full water and
land-agriculture nexus remains uncalibrated, and the case is not a reliability
model or decision-grade investment plan.

Do not edit runtime JSON by hand. Rebuild from the immutable
`Fiji_CLEWs_Global` reference with `scripts/build_fiji_v2.py`, apply Phase 1B
with `scripts/apply_fiji_phase1b_public_water.py`, apply Phase 1C with
`scripts/apply_fiji_phase1c_bottom_up_demand.py`, confirm the derived reserve
proxy is current, and rerun the automated solve and validation.
