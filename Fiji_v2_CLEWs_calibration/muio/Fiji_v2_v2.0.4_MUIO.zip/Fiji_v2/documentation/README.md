# Fiji v2 documentation pointers

The canonical tracked documentation lives in:

`../../../../Fiji_v2_CLEWs_calibration/`

Start with:

- `README.md`
- `documentation/CURRENT_MODEL.md`
- `documentation/CALIBRATION_PROTOCOL.md`
- `documentation/KNOWN_LIMITATIONS.md`
- `data_sources/evidence/calibration/`
- `diagnostics/calibration_runs/historical_fit/scorecard.md`
- `documentation/history/structural/PHASE_1B_PUBLIC_WATER_2026-07-27.md`
- `diagnostics/calibration_runs/phase1b/live_validation_summary.json`
- `documentation/history/structural/PHASE_1C_BOTTOM_UP_ELECTRICITY_DEMAND_2026-07-27.md`
- `data_sources/evidence/energy/PHASE_1C_PROJECTION_SOURCE_EXTRACTS_2026-07-27.md`
- `data_sources/calculation_notes/PHASE_1C_BOTTOM_UP_ELECTRICITY.md`
- `diagnostics/calibration_runs/phase1c/live_validation_summary.json`

This runtime directory contains solver parameters, view metadata, and results.
All changes must be generated and documented through the canonical v2 package.
