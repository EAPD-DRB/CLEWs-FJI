# Fiji v2 documentation pointers

The canonical tracked documentation lives in:

`../../../../Fiji_v2_CLEWs_calibration/`

Start with:

- `README.md`
- `documentation/CURRENT_MODEL.md`
- `documentation/CALIBRATION_PROTOCOL.md`
- `documentation/KNOWN_LIMITATIONS.md`
- `data_sources/evidence/calibration/`
- `diagnostics/calibration_runs/historical_fit/scorecard.md`

This runtime directory contains solver parameters, view metadata, and results.
All changes must be generated and documented through the canonical v2 package.
