# Fiji v2 active MUIO case

This folder is the active Fiji v2 runtime case. Its solved run,
`Historical_Backcast`, is an annual national grid-supply calibration
experiment with 2020–2022 calibration and frozen 2023–2024 held-out
validation.

- Canonical package: `../../../Fiji_v2_CLEWs_calibration/`
- Current model:
  `../../../Fiji_v2_CLEWs_calibration/documentation/CURRENT_MODEL.md`
- Sources and evidence:
  `../../../Fiji_v2_CLEWs_calibration/data_sources/`
- Assessment:
  `../../../Fiji_v2_CLEWs_calibration/diagnostics/calibration_runs/historical_fit/scorecard.md`
- Validation:
  `../../../Fiji_v2_CLEWs_calibration/diagnostics/calibration_runs/validation_summary.json`

The case is **Good, 76.4/100, medium confidence** for annual energy only.
It is not a calibrated full nexus, forecast, reliability model, or
decision-grade investment plan.

Do not edit runtime JSON by hand. Rebuild from the immutable
`Fiji_CLEWs_Global` reference with `scripts/build_fiji_v2.py`, update the
derived reserve proxy, and rerun the automated solve and validation.
